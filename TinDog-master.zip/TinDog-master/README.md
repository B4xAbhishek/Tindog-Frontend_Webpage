# How It Works

This is a landing page for a fictional dating app for dog owners to help their furry friends find soulmates. A user is able to scroll or click through to view the various sections of the SPA.

## Nitty Gritty
Based on one of the projects from Angela Yu's Udemy Web Development course, this single page web app was built with HTML and Bootstrap 4.0. 